<?php require_once 'engine/init.php'; include 'layout/overall/header.php'; ?>

<br><table class="blackline">
	<tr>
		<td><img src="layout/images/blank.gif"></td>
	</tr>
</table>
<div class="titleheader">
	<h1>Blank Page</h1>
</div>
<table class="blackline">
	<tr>
		<td><img src="layout/images/blank.gif"></td>
	</tr>
</table><br>
<p>This is a blank sample page.</p>

<?php include 'layout/overall/footer.php'; ?>