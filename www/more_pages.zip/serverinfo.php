<?php require_once 'engine/init.php'; include 'layout/overall/header.php'; ?>
<br><table class="blackline">
	<tr>
		<td><img src="layout/images/blank.gif"></td>
	</tr>
</table>
<div class="titleheader">
	<h1>Server Info</h1>
</div>
<table class="blackline">
	<tr>
		<td><img src="layout/images/blank.gif"></td>
	</tr>
</table><br>
Here you will find all basic information about <?php echo '<b>'.$config['site_title'].'</b>'; ?>
<br><br>
edit at .../www/serverinfo.php

<?php include 'layout/overall/footer.php'; ?>